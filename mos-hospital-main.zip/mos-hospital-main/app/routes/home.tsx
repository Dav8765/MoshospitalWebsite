import HomeSection from "~/components/sections/HomeSection";
import type { Route } from "./+types/home";
import FeaturesSection from "~/components/sections/FeaturesSection";
import DoctorsSection from "~/components/sections/DoctorsSection";
import PatientsSection from "~/components/sections/PatientsSection";
import ReviewSection from "~/components/sections/ReviewSection";
import ContactSection from "~/components/sections/ContactSection";
import SecurityCompliance from "~/components/sections/SecurityCompliance";
import OurMission from "~/components/sections/OurMission";
import TransparentPrice from "~/components/sections/TransparentPrice";
import DownloadGuide from "~/components/sections/DownloadGuide";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "MosHospital" },
    { name: "MosHospital", content: "Welcome to MosHospital!" },
  ];
}

export default function Home() {
  return (
    <>
      <HomeSection />
      <FeaturesSection />
      <DoctorsSection />
      <PatientsSection />
      <ReviewSection />
      <DownloadGuide/>
      <SecurityCompliance/>
      <OurMission/>
      <TransparentPrice/>
      <ContactSection />
    </>
  );
}
