import { IoIosArrowBack } from "react-icons/io";
import { Link } from "react-router";
import TermsCondition from "~/components/terms/TermsCondition";

export default function termsConditions() {
  return (
    <div className="container mx-auto mb-8 md:my-12 px-8 lg:px-0">
      <div className="flex justify-start ">
        <Link to="/">
          <p className="bg-primary p-3 text-2xl text-white rounded-full">
            <IoIosArrowBack />
          </p>
        </Link>
      </div>
      <h1 className="ml-5 -mt-12 text-center text-2xl md:text-5xl font-bold pb-2">Terms & Conditions</h1>
      <TermsCondition/>
    </div>
  );
}
