export type PricingType = {
    id: number;
    img: string;
    title: string;
    description : string;
}