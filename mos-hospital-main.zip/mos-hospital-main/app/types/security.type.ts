export type SecurityType = {
    id: number;
    img: string;
    title: string;
    description: string;
};