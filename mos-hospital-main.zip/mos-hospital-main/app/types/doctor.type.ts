export type DoctorCard = {
  id: number;
  image: string; // path to the image
  title: string;
  description: {
    text: string;
    bullets?: string[];
  };
};