export type Review = {
  id?: number;
  img: string;
  name: string;
  role: string;
  text: string;
};
