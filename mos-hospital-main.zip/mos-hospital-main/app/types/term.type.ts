export type PolicySection = {
  title: string;
  content?: string;
  items?: string[];
  table?: Array<{ key: string; value: string }>;
}

export type PrivacyPolicy = {
  effectiveDate: string;
  company: string;
  registeredAddress: string;
  email: string;
  sections: PolicySection[];
}