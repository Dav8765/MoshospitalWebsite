import { termsData } from "~/data/termsData";

export default function TermsCondition() {
  return (
    <div className="container mx-auto bg-primary/30 border rounded-[50px] border-primary p-8 lg:px-28 lg:py-16 mt-5 md:mt-10">
      <p className="text-black mb-4 text-xl font-medium">
        <strong>Effective Date:</strong> {termsData.effectiveDate} <br />
        <strong>Company:</strong> {termsData.company} <br />
        <strong>Registered Address:</strong> {termsData.registeredAddress}{" "}
        <br />
        <strong>Email:</strong> {termsData.email}
      </p>
      {/* point1 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">1. INTRODUCTION</h1>
        <p className="text-lg font-normal md:text-xl md:font-bold">
          MosHospital respects and protects your privacy. <br />
          This Privacy Policy explains how we collect, use, store, and protect
          your personal, medical, and financial information when you use our
          app, website, and related services (“Services”).
        </p>
        <p className="text-lg font-normal md:text-xl md:font-bold">
          By using MosHospital, you agree to the terms of this Privacy Policy
          and consent to the processing of your data as described herein.
        </p>
      </div>
      {/* point2 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          2. COMPLIANCE FRAMEWORKS
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold">
          MosHospital operates globally and adheres to international privacy and
          security standards, including:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-7 my-2">
          <li>🇪🇺 GDPR (General Data Protection Regulation)</li>
          <li>🇹🇷 KVKK / PDPL (Turkish Personal Data Protection Law) </li>
          <li>🇺🇸 HIPAA & CCPA (Healthcare and Consumer Privacy Laws) </li>
          <li>🇧🇷 LGPD (Brazilian General Data Protection Law) </li>
          <li> 🇿🇦 POPIA (South Africa)</li>
          <li> 🇮🇳 DPDP Act (India)</li>
          <li>🇮🇷 Iran Data Protection</li>
          <li>and Cyberspace Security Regulation</li>
        </ul>
        <p className="text-lg font-normal md:text-xl md:font-bold">
          MosHospital ensures that your data is collected and processed
          lawfully, fairly, and transparently in all regions.
        </p>
      </div>
      {/* point3 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          3. DATA WE COLLECT
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold">
          We collect only the data necessary to operate and improve our
          services.
        </p>
        <div>
          <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
            (a) Personal Information
          </p>
          <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
            <li> Full name, gender, date of birth, nationality</li>
            <li> Contact details (email, phone number)</li>
            <li>User ID and authentication tokens (Firebase UID)</li>
          </ul>
          <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
            (b) Medical Information
          </p>
          <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
            <li> Symptoms, consultation records, medical notes</li>
            <li>Uploaded health documents, prescriptions, and reports</li>
            <li>AI chat history (for performance and context improvement)</li>
          </ul>
          <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
            (c) Financial Information
          </p>
          <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
            <li> Payment details (via Iyzico and Payoneer)</li>
            <li>Transaction history and wallet balance</li>
            <li>Billing and refund data</li>
          </ul>
          <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
            (d) Technical Information
          </p>
          <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
            <li> Device ID, IP address, location (approximate)</li>
            <li>Browser type, OS, and activity logs</li>
            <li> Firebase Analytics and Cloud Monitoring data</li>
          </ul>
        </div>
      </div>
      {/* point4 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          4. PURPOSE OF DATA USE
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We process your data only for legitimate, clear purposes:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li> Purpose</li>
          <li>Legal Basis</li>
          <li>Account creation & authentication</li>
          <li>Contract necessity</li>
          <li>Appointment scheduling</li>
          <li>Legitimate interest</li>
          <li>AI health guidance</li>
          <li>User consent</li>
          <li>Payment processing</li>
          <li>Legal & financial obligations</li>
          <li>Security & fraud prevention</li>
          <li>Legitimate interest</li>
          <li>Analytics & service improvement</li>
          <li>Legitimate interest</li>
          <li>Compliance with health authorities</li>
          <li>Legal obligation</li>
          <li>Your data is never sold to advertisers or third parties.</li>
        </ul>
      </div>
      {/* point5 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          5. HOW WE STORE AND PROTECT YOUR DATA
        </h1>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>
            All user data is encrypted in transit (HTTPS) and at rest (AES-256).
          </li>
          <li>
            Medical data is stored in Firebase Cloud Firestore with access
            control and indexing.
          </li>
          <li>
            Payment information is handled securely by Iyzico and Payoneer, not
            by MosHospital directly.
          </li>
          <li>
            Cloud Functions and AI requests (via Groq API) use signed HTTPS
            tokens.
          </li>
        </ul>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We also use Firebase Monitoring to detect unusual activity or crashes,
          without exposing personal data.
        </p>
      </div>
      {/* point6 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          6. DATA RETENTION
        </h1>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>Account data: retained until account deletion.</li>
          <li>
            Medical & chat data: kept for 5 years (as required by Turkish Health
            Data Law).
          </li>
          <li>
            Financial data: retained per Iyzico/Payoneer regulation (usually 10
            years).
          </li>
          <li>Logs & analytics: stored for a maximum of 12 months.</li>
        </ul>

        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          You can request full data deletion at any time (see Section 10).
        </p>
      </div>
      {/* point7 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">7. DATA SHARING</h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We share data only when necessary and with strict protection
          agreements:
        </p>
        <ul className="space-y-1 text-lg font-normal md:text-xl md:font-bold ml-3 my-2">
          <li> Recipient</li>
          <li>Purpose</li>
          <li>Country</li>
          <li>Doctors (licensed users)</li>
          <li>Consultation and communication</li>
          <li>Local</li>
          <li> Iyzico / Payoneer</li>
          <li>Payments and withdrawals</li>
          <li>Turkey / Global</li>
          <li> Groq API</li>
          <li>AI health responses</li>
          <li>USA</li>
          <li>Firebase (Google Cloud)</li>
          <li>Data storage and analytics</li>
          <li>EU / Global</li>
          <li>Each partner complies with GDPR and PDPL standards.</li>
        </ul>

        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          You can request full data deletion at any time (see Section 10).
        </p>
      </div>
      {/* point8 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          {" "}
          8. AI DATA PROCESSING
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          Our AI system may temporarily process your input to generate health
          guidance. <br /> We do not train AI models on your private data.{" "}
          <br /> All requests are anonymized and logged only for performance and
          safety.
        </p>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          AI-generated output is intended for informational and educational
          purposes only — not as medical advice.
        </p>
      </div>
      {/* point9 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">9 . YOUR RIGHTS</h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          Depending on your jurisdiction, you may have the right to:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>Access your personal data</li>
          <li>Rectify inaccurate information</li>
          <li>Erase your data (“Right to be forgotten”)</li>
          <li>Restrict or object to processing</li>
          <li>Port your data to another service</li>
          <li>Withdraw consent at any time</li>
        </ul>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          To exercise these rights, email: privacy@moshospital.org
        </p>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We respond within 30 days under GDPR and 45 days under KVKK or other
          frameworks.
        </p>
      </div>
      {/* point9 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">9 . YOUR RIGHTS</h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          Depending on your jurisdiction, you may have the right to:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>Access your personal data</li>
          <li>Rectify inaccurate information</li>
          <li>Erase your data (“Right to be forgotten”)</li>
          <li>Restrict or object to processing</li>
          <li>Port your data to another service</li>
          <li>Withdraw consent at any time</li>
        </ul>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          To exercise these rights, email: privacy@moshospital.org
        </p>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We respond within 30 days under GDPR and 45 days under KVKK or other
          frameworks.
        </p>
      </div>
      {/* point10 */}
      <div className="my-7">
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          10. DATA DELETION REQUEST
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          You can delete your account directly from the app settings, or by
          contacting us via email. <br /> Upon deletion:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>
            Your AI history, appointments, and wallet data are permanently
            removed (except where law requires retention).
          </li>
          <li>Backup data will be deleted within 30 days.</li>
        </ul>
      </div>
      {/* point11 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          11. INTERNATIONAL DATA TRANSFER
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          As MosHospital operates globally, your data may be transferred
          securely to servers in the EU, USA, or other compliant regions.
        </p>
        <p>
          We use Standard Contractual Clauses (SCCs) and adequacy decisions
          approved by the European Commission to protect your rights.
        </p>
      </div>
      {/* point12 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          12. COOKIES & TRACKING
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          MosHospital uses cookies and Firebase Analytics to:
        </p>
        <ul className="list-disc space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>Remember session preferences</li>
          <li>Improve app performance</li>
          <li>Analyze anonymous user behavior</li>
        </ul>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          You can manage or disable cookies in your device or browser settings.
        </p>
      </div>
      {/* point13 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          13. CHILDREN’S PRIVACY
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          MosHospital does not knowingly collect data from children under 16
          years without parental consent. <br /> If such data is detected, it
          will be deleted immediately upon verification.
        </p>
      </div>
      {/* point14 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          14. CHANGES TO THIS POLICY
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          We may occasionally update this Privacy Policy. <br />
          All updates will be published in-app and on our website.
          <br />
          Continued use of our services means you accept the updated version.
        </p>
      </div>
      {/* point15 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          15. CONTACT INFORMATION
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          If you have privacy questions, complaints, or data requests, contact
          our Data Protection Officer (DPO):
        </p>

        <ul className="space-y-1 text-lg font-normal md:text-xl md:font-bold ml-9 my-2">
          <li>📧 privacy@moshospital.org</li>
          <li>📍 Istanbul, Turkey</li>
        </ul>
      </div>
      {/* point16 */}
      <div>
        <h1 className="text-2xl md:text-4xl font-bold mb-5">
          {" "}
          16. GOVERNING LAW
        </h1>
        <p className="text-lg font-normal md:text-xl md:font-bold ml-2 my-2">
          This Privacy Policy is governed by Turkish PDPL (KVKK) and complies
          with GDPR and other international privacy frameworks.
        </p>
      </div>
    </div>
  );
}
