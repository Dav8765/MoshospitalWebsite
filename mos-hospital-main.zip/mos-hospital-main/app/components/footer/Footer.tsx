import React from "react";
import { Link } from "react-router";

export default function Footer() {
  return (
    <div className="bg-[#1E65C1] py-12">
      <div className="container mx-auto space-y-2">
        <p className="text-center text-white text-lg md:text-2xl">
          © 2025 MosHospital. All rights reserved.
        </p>
        <h1 className="text-white font-bold text-base md:text-[24px] text-center">
          Made by David Ekofo Musoso — Designed with purpose. Built for
          humanity.
        </h1>
        <div className="flex flex-col md:flex-row justify-center items-center text-white gap-2 md:gap-5">
          <p className="text-sm md:text-base">📧 contact@moshospital.org </p>
          <p className="md:block hidden">|</p>
          <p className="text-sm md:text-base">🌍 www.moshospital.org </p>
          <p className="md:block hidden">|</p>
          <p className="text-sm md:text-base flex gap-2 items-center"> <img src="/turkeyFlag.svg" alt="" className="size-5"/> Istanbul, Turkey</p>
        </div>
        <div className="text-center">
          <Link to="/terms-conditions" className="text-white underline mr-4">
            Privacy Policy
          </Link>
          <Link to="/terms-conditions" className="text-white underline">
            Terms of Service
          </Link>
        </div>
      </div>
    </div>
  );
}
