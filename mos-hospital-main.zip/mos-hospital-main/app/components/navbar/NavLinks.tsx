import { useEffect, useState } from "react";
import { HiMenuAlt3, HiX } from "react-icons/hi";
import { Events, Link, scrollSpy } from "react-scroll";

const navLinks = [
  { name: "Home", to: "home" },
  { name: "Features", to: "features" },
  { name: "Doctors", to: "doctors" },
  { name: "Patients", to: "patients" },
  { name: "Review", to: "review" },
  { name: "Security", to: "security" },
  { name: "Mission", to: "mission" },
  { name: "Pricing", to: "pricing" },
  { name: "Contact", to: "contact" },
];

export default function NavLinks() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<string>("home");

  useEffect(() => {
    Events.scrollEvent.register("begin", () => {});
    Events.scrollEvent.register("end", () => {});
    scrollSpy.update();

    return () => {
      Events.scrollEvent.remove("begin");
      Events.scrollEvent.remove("end");
    };
  }, []);

  return (
    <header className="fixed top-0 left-0 w-full bg-white z-50">
      <nav className="container mx-auto flex items-center justify-between px-4 sm:px-6 py-3">
        {/* Logo */}
        <div className="">
          <img
            src="/logo.svg"
            alt="MosHospital"
            className="h-12 w-12 sm:h-16 sm:w-16"
          />
        </div>

        {/* Desktop Nav */}
        <ul className="hidden lg:flex space-x-4 px-4 py-3 border border-[#0000001C] rounded-full">
          {navLinks.map((link) => (
            <li key={link.to}>
              <Link
                to={link.to}
                smooth={true}
                duration={500}
                offset={-80}
                spy={true}
                onSetActive={() => setActiveSection(link.to)}
                className={`px-4 py-2 font-bold cursor-pointer transition-colors rounded-full ${
                  activeSection === link.to
                    ? "bg-blue-600 text-white"
                    : "text-gray-800 hover:text-blue-600 "
                }`}
              >
                {link.name}
              </Link>
            </li>
          ))}
        </ul>

        {/* Desktop Download Button */}
        <div className="hidden lg:block">
          <button className="bg-blue-600 text-white font-semibold px-6 py-2 rounded-full hover:bg-blue-700 transition">
            Download now
          </button>
        </div>

        {/* Mobile Menu Icon */}
        <button
          className="lg:hidden text-3xl text-gray-700"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <HiX /> : <HiMenuAlt3 />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="fixed top-16 left-0 w-full bg-white shadow-md border-t border-gray-100 lg:hidden z-40">
          <ul className="flex flex-col items-center py-4 space-y-4">
            {navLinks.map((link) => (
              <li key={link.to}>
                <Link
                  to={link.to}
                  smooth={true}
                  duration={500}
                  offset={-70}
                  onClick={() => setIsOpen(false)}
                  className="text-gray-800 font-medium hover:text-blue-600 cursor-pointer transition-colors"
                >
                  {link.name}
                </Link>
              </li>
            ))}
            <button className="bg-blue-600 text-white font-semibold px-6 py-2 rounded-full hover:bg-blue-700 transition">
              Download now
            </button>
          </ul>
        </div>
      )}
    </header>
  );
}
