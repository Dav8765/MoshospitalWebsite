import { priceData } from "~/data/pricingData";

export default function TransparentPrice() {
  return (
    <div id="pricing" className="container mx-auto py-16 text-center space-y-5 ">
      <h1 className=" text-3xl md:text-5xl font-bold mb-16">Transparent Price</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {priceData.map((price) => (
          <div key={price.id} className=" bg-[#F8F8F8] rounded-2xl p-5 md:p-12 space-y-3 text-start">
            <img src={price?.img} alt={price?.title} />
            <p className="text-lg md:text-2xl font-bold">{price?.title}</p>
            <p className="text-lg md:text-2xl font-normal">
              {price?.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
