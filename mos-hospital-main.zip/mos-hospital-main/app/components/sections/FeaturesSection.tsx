export default function FeaturesSection() {
  return (
    <section
      id="features"
      className="relative w-full text-white overflow-hidden my-10"
    >
      {/* Background shape */}
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: "url('/feature-bg.svg')", // replace with your actual image
        }}
      />

      {/* Blue overlay */}
      <div className="absolute inset-0 bg-[#1E65C1]/70" />

      {/* Left image */}
      <img
        src="/feature-left.svg"
        alt="Left decoration"
        className="absolute left-0 top-1/2 transform -translate-y-1/2 w-24 sm:w-32 lg:w-40"
      />

      {/* Right image */}
      <img
        src="/feature-right.svg"
        alt="Right decoration"
        className="absolute right-0 top-1/2 transform -translate-y-1/2 w-24 sm:w-32 lg:w-40"
      />

      {/* Content */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center px-6 py-20 md:py-24 lg:py-28 max-w-3xl mx-auto">
        <h2 className="text-2xl sm:text-3xl lg:text-5xl font-bold mb-3">
          Healthcare Access is Still Complicated.
        </h2>
        <p className="text-sm sm:text-base lg:text-lg text-[#9AC6FF] max-w-2xl">
          We combine AI-powered diagnostics, real-time communication, and secure
          payments to create a connected healthcare system for everyone.
        </p>
      </div>
    </section>
  );
}
