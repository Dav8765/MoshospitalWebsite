

export default function OurMission() {
  return (
    <div id="mission" className="container mx-auto py-16 text-center space-y-5 ">
        <h1 className=" text-3xl md:text-5xl font-bold">Our mission</h1>
        <p className="text-lg md:text-4xl font-bold max-w-5xl mx-auto">To create a world where quality healthcare is accessible, intelligent, and connected. MosHospital unites human compassion and AI precision to build the next era of medicine.</p>
    </div>
  )
}
