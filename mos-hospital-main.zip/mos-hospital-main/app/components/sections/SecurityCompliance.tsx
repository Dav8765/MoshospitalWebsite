import { securityData } from "~/data/securityData";

export default function SecurityCompliance() {
  return (
    <div id="security" className="container mx-auto py-6 md:py-16 text-center space-y-5 ">
      <h1 className="text-2xl md:text-5xl font-bold text-center mb-26">
        Security & Compliance
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-7">
        {securityData.map((security) => (
          <div key={security?.id} className="bg-[#1E65C1] text-white p-5 md:py-10 md:px-16 rounded-2xl text-start space-y-3">
            <img src={security.img} alt={security?.title} />
            <h1 className="tex-xl md:text-3xl font-bold">{security?.title}</h1>
            <p className="font-normal text-lg md:text-2xl">{security?.description}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
