import { MdFileDownload } from "react-icons/md";

export default function PatientsSection() {
  return (
    <section
      id="patients"
      className=" bg-[#1E65C1] container mx-auto mt-9 rounded-2xl text-white"
    >
      <div className="flex flex-col-reverse lg:flex-row  justify-around items-center">
        <div className="flex-1 py-20 px-5 md:px-[108px] space-y-5">
          <h1 className="text-3xl md:text-5xl font-bold">HOW IT WORKS ?</h1>
          <p className="text-[#C3C3C3] font-medium">
            Your Health Journey, Simplified.
          </p>
          <ul className="space-y-2">
            <li className="text-sm md:text-xl font-bold">
              1. Search a Doctor by specialty or location.
            </li>
            <li className="text-sm md:text-xl font-bold">
              2. Book & Pay your consultation directly in the app.
            </li>
            <li className="text-sm md:text-xl font-bold">
              3. Chat or Video Call your doctor in real-time.
            </li>
            <li className="text-sm md:text-xl font-bold">
              4. Receive AI Diagnostic and follow-up.
            </li>
          </ul>
          <button className="uppercase text-black bg-white px-8 py-2 md:py-4 md:px-14 flex gap-2 justify-center items-center rounded-full text-sm md:text-xl font-bold">
            <MdFileDownload className=" md:text-2xl" /> Download The App Now
          </button>
        </div>
        <div className="flex-1 p-5 md:p-[70px]">
          <img src="/Phone.png" alt="" />
        </div>
      </div>
    </section>
  );
}
