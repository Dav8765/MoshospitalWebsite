export default function HeroContent() {
  return (
    <div className="text-center">
      {/* --- Main Headings --- */}
      <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold leading-tight tracking-tight">
        <span className="block">You Deserve Care</span>
        <span className="block">That Truly Cares</span>
      </h1>

      <p className="mt-4 text-lg sm:text-xl md:text-2xl text-gray-300 max-w-2xl mx-auto">
        Real doctors, real support, and AI that listens all here to guide you,
        day or night.
      </p>

      <div className="mt-12 w-full max-w-4xl mx-auto">
        <div className="relative pt-[56.25%] rounded-lg shadow-2xl overflow-hidden cursor-pointer border border-black transition duration-300">
          <div
            className="absolute inset-0 flex items-center justify-center bg-cover bg-center"
            style={{
              backgroundImage: "url('/homeVideoImage.svg')",
            }}
          >
            <div className="w-20 h-20 sm:w-24 sm:h-24  backdrop-blur-sm rounded-full flex items-center justify-center border-4 border-white/50">
              <svg
                width="89"
                height="89"
                viewBox="0 0 89 89"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <mask
                  id="mask0_332_30"
                //   style="mask-type:luminance"
                  maskUnits="userSpaceOnUse"
                  x="0"
                  y="0"
                  width="89"
                  height="89"
                >
                  <path
                    d="M44.3333 87.6667C68.2663 87.6667 87.6667 68.2663 87.6667 44.3333C87.6667 20.4003 68.2663 1 44.3333 1C20.4003 1 1 20.4003 1 44.3333C1 68.2663 20.4003 87.6667 44.3333 87.6667Z"
                    fill="white"
                    stroke="white"
                    stroke-width="2"
                    stroke-linejoin="round"
                  />
                  <path
                    d="M35.6665 44.3334V29.3227L48.6665 36.828L61.6665 44.3334L48.6665 51.8387L35.6665 59.344V44.3334Z"
                    fill="black"
                    stroke="black"
                    stroke-width="2"
                    stroke-linejoin="round"
                  />
                </mask>
                <g mask="url(#mask0_332_30)">
                  <path
                    d="M-7.6665 -7.66669H96.3335V96.3333H-7.6665V-7.66669Z"
                    fill="white"
                  />
                </g>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
