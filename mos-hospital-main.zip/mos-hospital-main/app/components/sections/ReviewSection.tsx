import TestimonialsSlider from "./TestimonialsSlider";


export default function ReviewSection() {
  return (
    <section id="review">
        <h1 className="text-2xl md:text-5xl font-bold text-center pt-16 md:py-[63px]">What Our Early Users Say</h1>
        <TestimonialsSlider/>
    </section>
  )
}
