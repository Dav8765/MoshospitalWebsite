import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/pagination";
import "swiper/css/grid";
import { Pagination, Autoplay, Grid } from "swiper/modules";
import "../../css/testimonialsSlider.css";
import { testimonials } from "~/data/reviewData";

const TestimonialsSlider = () => {
  return (
    <div className="testimonials-container container mx-auto py-16">
      <Swiper
        modules={[Pagination, Autoplay, Grid]}
        spaceBetween={40}
        slidesPerView={3}
        grid={{ rows: 2, fill: "row" }}
        autoplay={{ delay: 4000 }}
        pagination={{ clickable: false }}
        breakpoints={{
          320: { slidesPerView: 1, grid: { rows: 1 } },
          768: { slidesPerView: 2, grid: { rows: 2 } },
          1024: { slidesPerView: 4, grid: { rows: 2 } },
        }}
      >
        {testimonials.map((item, i) => (
          <SwiperSlide key={i}>
            <div className={`testimonial-card ${i % 2 === 1 ? "offset" : ""} max-w-7xl`}>
              <img src={item.img} alt={item.name} className="testimonial-img" />
              <h3>{item.name}</h3>
              <p className="role">{item.role}</p>
              <p className="text">{item.text}</p>
            </div>
          </SwiperSlide>
        ))}
      </Swiper>
    </div>
  );
};

export default TestimonialsSlider;
