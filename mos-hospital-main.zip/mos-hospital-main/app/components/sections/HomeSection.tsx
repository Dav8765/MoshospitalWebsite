import HealthcareHero from "./HealthcareHero";
import HeroContent from "./HeroContent";

export default function HomeSection() {
  return (
    <section
      id="home"
      className="container mx-auto bg-[#141414] text-white rounded-2xl overflow-hidden"
    >
      <HealthcareHero>
      <HeroContent />
    </HealthcareHero>
    </section>
  );
}
