import { LuDot } from "react-icons/lu";
import { doctorsData } from "~/data/doctorData";

export default function DoctorsSection() {
  return (
    <section id="doctors" className="container mx-auto">
      <div className="py-16 space-y-3">
        <h1 className="text-2xl md:text-5xl font-bold text-center ">
          Mos Hospital Makes It Simple.
        </h1>
        <p className="max-w-3xl mx-auto text-sm md:text-xl text-center font-medium text-[#999999] ">
          We combine AI-powered diagnostics, real-time communication, and secure payments to create a connected healthcare system for everyone.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {doctorsData.map((doctor) => (
          <div key={doctor?.id} >
            <div className="bg-[#F8F8F8] hover:bg-[#1E65C1] hover:text-white p-5 md:py-10 md:px-11 rounded-2xl space-y-3">
              <img
                src={doctor?.image}
                alt={doctor?.title}
                className="bg-white p-3 rounded-full"
              />
              <h1 className="font-bold text-xl md:text-3xl">{doctor?.title}</h1>
              <p className="text-sm md:text-xl font-medium">{doctor?.description?.text}</p>
              {doctor?.description?.bullets && (
                <ul>
                  {doctor.description.bullets.map((bullet, index) => (
                    <li key={index} className="flex items-center">
                      <LuDot />
                      {bullet}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
