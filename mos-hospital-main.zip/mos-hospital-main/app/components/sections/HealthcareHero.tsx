import type { ReactNode } from "react";

interface HealthcareHeroProps {
  // Use ReactNode for children to accept any valid JSX element, string, or array
  children: ReactNode;
}
const HealthcareHero: React.FC<HealthcareHeroProps> = ({ children }) => {
  return (
    // Outer container for dark background and padding
    <div className="min-h-screen py-10 md:py-20 flex items-center justify-center relative overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center opacity-70"
        style={{
          backgroundImage: "url('/homebcg.jpg')",
          backgroundSize: "cover",
          backgroundRepeat: "no-repeat",
          backgroundPosition: "center top",
        }}
        aria-hidden="true" 
      ></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
        {children}
      </div>
    </div>
  );
};

export default HealthcareHero;
