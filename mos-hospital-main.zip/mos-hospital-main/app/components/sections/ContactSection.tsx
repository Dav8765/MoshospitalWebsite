import { AiOutlineTikTok } from "react-icons/ai";
import { IoLogoInstagram } from "react-icons/io";
import { RiTwitterXLine } from "react-icons/ri";
import { Link } from "react-router";

export default function ContactSection() {
  return (
    <section id="contact" className="container mx-auto py-16 space-y-2">
      <h1 className="text-center text-3xl md:text-5xl font-bold pb-2">
        Contact Us
      </h1>
      <p className="text-lg md:text-2xl font-bold text-center">
        Have a partnership or support request? Reach out to us anytime.
      </p>
      <p className="text-lg md:text-2xl font-bold text-center">
        contact@moshospital.com
      </p>
      <div className="flex gap-5 justify-center items-center mt-5">
        <Link
          to="/contact"
          className="border border-[#00000033] p-2 rounded-full"
        >
          <IoLogoInstagram className="text-2xl" />
        </Link>
        <Link
          to="/contact"
          className="border border-[#00000033] p-2 rounded-full"
        >
          <AiOutlineTikTok className="text-2xl" />
        </Link>
        <Link
          to="/contact"
          className="border border-[#00000033] p-2 rounded-full"
        >
          <RiTwitterXLine className="text-2xl" />
        </Link>
      </div>
    </section>
  );
}
