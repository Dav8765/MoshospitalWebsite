export default function DownloadGuide() {
  return (
    <div className="container mx-auto">
      <div className="relative w-full h-screen overflow-hidden flex items-center rounded-3xl">
        {/* RIGHT SIDE BACKGROUND */}
        <div className="absolute inset-0 bg-[#1E65C1]" />

        {/* LEFT SIDE GRADIENT WITH CENTER S-CURVE */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 800 1400"
          preserveAspectRatio="none"
        >
          <defs>
            <linearGradient id="leftGrad" x1="1" x2="0" y1="0" y2="0">
              <stop offset="0%" stopColor="#124484" />
              <stop offset="100%" stopColor="#04101E" />
            </linearGradient>
          </defs>

          <path
            d="
        M300 0
        C200 250 200 450 300 700
        C400 950 400 1150 300 1400
        L0 1400
        L0 0
        Z
      "
            fill="url(#leftGrad)"
          />
        </svg>

        {/* CONTENT */}
        <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 max-w-5xl w-full mx-auto px-10 gap-16">
          {/* LEFT CONTENT (Gradient side) */}
          <div className="flex justify-center items-center">
            <img src="/phone2.png" alt="demo" className=" drop-shadow-xl" />
          </div>

          {/* RIGHT CONTENT (Blue side) */}
          <div className="text-white flex flex-col justify-center space-y-4">
            <p className="text-xl opacity-90">
              Are ready for this new journey ?
            </p>
            <h1 className="text-3xl font-bold leading-snug">
              Download our app available <br /> across all platform
            </h1>

            <div className="flex items-center justify-center md:justify-start gap-4 pt-4">
              <button className="bg-[#FFFFFF33] text-black px-6 py-3 rounded-full flex items-center gap-2 shadow-lg">
                <img src="/playstore.svg" alt="" />
                App Store
              </button>
              <button className="bg-[#FFFFFF33] text-black px-6 py-3 rounded-full flex items-center gap-2 shadow-lg">
                <img src="/apple.svg" alt="" />
                Play Store
              </button>
            </div>
          </div>
        </div>
      </div>
      
    </div>
  );
}
