import type { Review } from "~/types/review.types";

export const testimonials : Review[] = [
  {
    img: "/review1.svg",
    name: "Dr. Sarah O",
    role: "Cardiologist",
    text: "MosHospital has simplified how I manage my appointments and patient communication. The integrated chat and file sharing are game changers for remote consultations."
  },
  {
    img: "/review1.svg",
    name: "Dr. Mehmet Kaya",
    role: "General Practitioner, Turkey",
    text: "Before MosHospital, I spent hours organizing schedules and patient records. Now everything is synced and accessible from one secure dashboard — it’s brilliant."
  },
  {
    img: "/review1.svg",
    name: " Dr. Lisa Chibanda",
    role: "Dermatologist, South Africa",
    text: "The connection between patients and specialists is faster than ever. I receive verified appointments and can track each case in real time. Truly next-level innovation."
  },
  {
    img: "/review2.svg",
    name: " Aisha B.",
    role: "Patient",
    text: "I found my doctor in less than five minutes! The map and instant chat made the whole process so easy — I didn’t even have to call anyone.",
  },
  {
    img: "/review2.svg",
    name: "Marc D.",
    role: "Patient",
    text: "What impressed me most was how transparent everything felt. I could compare doctors, read their reviews, and talk directly with them before booking.",
  },
  {
    img: "/review2.svg",
    name: "Elif T.",
    role: "Patient",
    text: "It’s like having a personal health assistant in your pocket. I use MosHospital to schedule, consult, and even order medical products.",
  },
  {
    img: "/review3.svg",
    name: "Mr. Abdullah Yılmaz",
    role: "Hospital IT Director",
    text: "We integrated MosHospital into our internal system within weeks. The real-time data flow between departments has reduced waiting time by 40%.",
  },
  {
    img: "/review3.svg",
    name: "Dr. Nadia Hassan",
    role: "Clinic Owner",
    text: "MosHospital helped our clinic reach new patients who never knew we existed. It’s not just software — it’s a growth accelerator for healthcare providers.",
  },
  {
    img: "/review4.svg",
    name: "Kevin R.",
    role: "CEO, MedTech Africa",
    text: "The MosHospital ecosystem bridges a massive gap between healthcare professionals and patients in emerging markets. This is what digital health was meant to be.",
  },
  {
    img: "/review4.svg",
    name: "Selin Aydin",
    role: "CEO, CareLink Solutions",
    text: "From UX design to backend stability, MosHospital represents the kind of startup that redefines healthcare technology. It’s both visionary and practical.",
  },
  
];