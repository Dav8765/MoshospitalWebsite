import type { SecurityType } from "~/types/security.type";

export const securityData : SecurityType[] = [
  {
    id: 1,
    img: "/lock.svg",
    title: "Data Protection",
    description:
      "End-to-end encryption and HIPAA-inspired data security for all users.",
  },
  {
    id: 2,
    img: "/brain.svg",
    title: "Ethical AI",
    description:
      "Our AI follows transparent, human-centered principles to support healthcare professionals.",
  },
  {
    id: 3,
    img: "/bank.svg",
    title: "Secure Payments",
    description:
      "Instant, safe transactions through iyzico and payonner.",
  },
  {
    id: 3,
    img: "/law.svg",
    title: "GDPR & KVKK & HIPAA & NDPR & POPIA & PDPA & PIPL & DPDP & LGPD(brazil) & Habeas Data  Laws & Computer Crimes Law (2009) and Telemedicine & E-Health Data Protection Guidelines Compliant",
    description:
      "We protect every patient’s data across borders privacy, transparency, and ethics come first.",
  },
];
