import type { DoctorCard } from "~/types/doctor.type";

export const doctorsData: DoctorCard[] = [
  {
    id: 1,
    image: "/one.svg",
    title: "AI That Assists, Not Replaces.",
    description: {
      text: "Our AI provides smart pre-diagnosis to assist both doctors and patients improving accuracy and saving lives.Built with data privacy and ethical AI principles.",
    },
  },
  {
    id: 2,
    image: "/two.svg",
    title: "Your Health, One Tap Away.",
    description: {
      text: "Book trusted doctors near you or abroad, get fast support, and store your health data safely. Mos Hospital puts the power of healthcare in your hands.",
    },
  },
  {
    id: 3,
    image: "/three.svg",
    title: "Built for Doctors, Trusted by Patients.",
    description: {
      text: "Manage appointments, payments, and patient records with simplicity. Mos Hospital helps you focus on what matters most healing people.",
      bullets: [
        "Smart dashboard",
        "Instant notifications",
        "Appointment calendar",
        "Patient history and analytics",
      ],
    },
  },
  {
    id: 4,
    image: "/four.svg",
    title: "Built for Hospitals, Made for Teams",
    description: {
      text: "Oversee doctors and appointments with ease. Mos Hospital Admin keeps your institution running efficiently and transparently.",
      bullets: [
        "Monitor doctor activity and schedules",
        "Verify doctor credentials and performance",
        "iew and manage all appointments in one place",
        "Access real-time analytics and patient insights",
      ],
    },
  },
  {
    id: 5,
    image: "/five.svg",
    title: "Smart Wallet for Modern Healthcare.",
    description: {
      text: "Patients can store money securely or pay instantly using Stripe or PayTR. Doctors can withdraw directly to their bank accounts with transparency and zero delay.",
    },
  },
  {
    id: 6,
    image: "/language.svg",
    title: "Languages",
    description: {
      text: "Our applications support 7 languages which are : English, French, Portuguese, Spanish, Arabic and Persian.",
    },
  }
];
