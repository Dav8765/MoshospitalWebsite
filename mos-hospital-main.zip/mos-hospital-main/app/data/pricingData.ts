import type { PricingType } from "~/types/pricing.type";

export const priceData: PricingType[] = [
  {
    id: 1,
    img: "/patients.svg",
    title: "For Patients",
    description:
      "Free to use. Pay only for consultations and premium AI insights.",
  },
  {
    id: 2,
    img: "/doctors.svg",
    title: "For Doctors",
    description:
      "Commission-based earnings with instant payouts and full control over your schedule.",
  },
  {
    id: 1,
    img: "/hospitals.svg",
    title: "For Hospitals",
    description:
      "Enterprise-grade analytics, integrations, and real-time data dashboards.",
  },
];
