import type { PrivacyPolicy } from "~/types/term.type";

export const termsData: PrivacyPolicy = {
  effectiveDate: "Wednesday, November 12, 2025",
  company: "MosHospital Teknoloji",
  registeredAddress: "Istanbul, Turkey",
  email: "privacy@moshospital.org",

  sections: [
    {
      title: "1. INTRODUCTION",
      content:
        "MosHospital respects and protects your privacy. \n This Privacy Policy explains how we collect, use, store, and protect your personal, medical, and financial information when you use our Services. By using MosHospital, you agree to the terms of this Privacy Policy."
    },

    {
      title: "2. COMPLIANCE FRAMEWORKS",
      items: [
        "GDPR (Europe)",
        "KVKK / PDPL (Turkey)",
        "HIPAA & CCPA (USA)",
        "LGPD (Brazil)",
        "POPIA (South Africa)",
        "DPDP Act (India)",
        "Iran Data Protection Regulation"
      ]
    },

    {
      title: "3. DATA WE COLLECT",
      items: [
        "Personal Information: name, gender, birth date, nationality, contact details, authentication tokens.",
        "Medical Information: symptoms, consultation records, documents, prescriptions, AI chat history.",
        "Financial Information: payments via Iyzico & Payoneer, wallet, refund data.",
        "Technical Information: device ID, IP address, location, OS, logs, Firebase analytics."
      ]
    },

    {
      title: "4. PURPOSE OF DATA USE",
      table: [
        { key: "Account creation & authentication", value: "Contract necessity" },
        { key: "Appointment scheduling", value: "Legitimate interest" },
        { key: "AI health guidance", value: "User consent" },
        { key: "Payment processing", value: "Legal & financial obligations" },
        { key: "Security & fraud prevention", value: "Legitimate interest" },
        { key: "Analytics & improvement", value: "Legitimate interest" },
        { key: "Compliance with health authorities", value: "Legal obligation" }
      ]
    },

    {
      title: "5. HOW WE STORE AND PROTECT YOUR DATA",
      items: [
        "All data encrypted in transit (HTTPS) and at rest (AES-256).",
        "Medical data stored in Firebase Firestore with strict access control.",
        "Payments handled securely by Iyzico and Payoneer.",
        "Cloud Functions use signed HTTPS tokens.",
        "Firebase Monitoring tracks unusual activity without exposing personal data."
      ]
    },

    {
      title: "6. DATA RETENTION",
      items: [
        "Account data retained until deletion.",
        "Medical & chat data kept 5 years (Turkey health law).",
        "Financial records kept 10 years (Iyzico/Payoneer).",
        "Analytics kept max 12 months."
      ]
    },

    {
      title: "7. DATA SHARING",
      table: [
        { key: "Doctors", value: "Consultations (Local)" },
        { key: "Iyzico / Payoneer", value: "Payments (Turkey / Global)" },
        { key: "Groq API", value: "AI responses (USA)" },
        { key: "Firebase", value: "Storage & analytics (EU / Global)" }
      ]
    },

    {
      title: "8. AI DATA PROCESSING",
      content:
        "AI temporarily processes your input to generate responses. Data is anonymized and never used to train models. AI outputs are informational only and not medical advice."
    },

    {
      title: "9. YOUR RIGHTS",
      items: [
        "Access your data",
        "Rectify incorrect data",
        "Request deletion",
        "Restrict processing",
        "Object to processing",
        "Data portability",
        "Withdraw consent anytime"
      ]
    },

    {
      title: "10. DATA DELETION REQUEST",
      items: [
        "You can delete your account via app settings or email.",
        "Your data (AI, appointments, wallet) is permanently deleted except where law requires retention.",
        "Backups removed within 30 days."
      ]
    },

    {
      title: "11. INTERNATIONAL DATA TRANSFER",
      content:
        "Data may be transferred securely to servers in EU, USA, or compliant regions using SCCs and adequacy decisions."
    },

    {
      title: "12. COOKIES & TRACKING",
      items: [
        "Session preferences",
        "Performance improvement",
        "Anonymous analytics"
      ]
    },

    {
      title: "13. CHILDREN’S PRIVACY",
      content:
        "We do not collect data from children under 16 without parental consent. If detected, data is removed immediately."
    },

    {
      title: "14. CHANGES TO THIS POLICY",
      content:
        "Updates may occur periodically. Continued use of MosHospital means acceptance of updated terms."
    },

    {
      title: "15. CONTACT INFORMATION",
      content:
        "Email: privacy@moshospital.org — Istanbul, Turkey"
    },

    {
      title: "16. GOVERNING LAW",
      content:
        "Governed by Turkish PDPL (KVKK) and compliant with GDPR and international standards."
    }
  ]
};
