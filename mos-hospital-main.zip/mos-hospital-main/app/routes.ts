import { type RouteConfig, index, route } from "@react-router/dev/routes";

export default [
  index("routes/home.tsx"),
  route("terms-conditions", "routes/terms-conditions.tsx"),
] satisfies RouteConfig;
